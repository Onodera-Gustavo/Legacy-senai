from django.contrib import admin
from django.urls import path
from mycontacts import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.contact_list, name='contact_list'),
    path('add/', views.add_contact, name='add_contact'),
    path('edit/<int:pk>/', views.edit_contact, name='edit_contact'),
    path('delete/<int:pk>/', views.delete_contact, name='delete_contact'),
]