﻿# Exercícios Django

Criação de models, views, templates e suas dependências.
Manipulação de branchs e métodos de aplicação.
